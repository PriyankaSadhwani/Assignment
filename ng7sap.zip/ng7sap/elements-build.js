const fs = require('fs-extra');
const concat = require('concat');

(async function build() {
  const files = [
    './dist/ng7sap/runtime.js',
    './dist/ng7sap/polyfills.js',
    './dist/ng7sap/scripts.js',
    './dist/ng7sap/main.js'
  ];

  await fs.ensureDir('elements');
  await concat(files, 'elements/ng7sap.js');
  await fs.copyFile(
    './dist/ng7sap/styles.css',
    'elements/styles.css'
  );
})();